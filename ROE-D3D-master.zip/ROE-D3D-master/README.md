
BOX (ok)
LINE (ok)
AIMBOT (OK)
DISTANCE (need to improve)
BOX ALIGNMENT (Need to Repair)
CHAMS (Stops Working)

I recommend installing
- Visual Studio 2017
- DXSDK Microsoft DirectX SDK (June 2010) [Resolves error d3dx9.h]
- Microsoft Visual C++ 2017 Redistributable
